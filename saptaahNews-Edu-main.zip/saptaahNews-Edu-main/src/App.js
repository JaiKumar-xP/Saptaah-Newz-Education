import './App.css';
import Education from "./Education";

function App() {
  return (
    <div className="App">
      <Education/>
    </div>
  );
}

export default App;
